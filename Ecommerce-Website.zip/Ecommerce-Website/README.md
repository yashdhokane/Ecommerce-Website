

# Ecommerce Project in PHP CodeIgniter

## Introduction

This is a simple e-commerce project built using PHP and CodeIgniter. It allows users to browse products, add them to their cart, and checkout.

## Features

* Browse products by category
* Add products to cart
* Checkout and pay for products
* Manage orders

## Installation

To install this project, you will need:

* PHP 7.2 or later
* MySQL 5.6 or later
* CodeIgniter 3.1 or later

Once you have these prerequisites installed, you can clone this repository and run the following commands:


## Usage

To use this project, simply visit the following URL in your browser:


You can then browse products, add them to your cart, and checkout.

## Contributing

If you would like to contribute to this project, please feel free to fork it and submit a pull request.

## License

This project is licensed under the MIT license.

## How to use
How to Use IT..... 
Go to your PHP my admin Then create a Database name ecommerce_codeigniter then import sql from under zip file Using Default configuration: username:root password:"" db_host:localhost db_name:ecommerce_codeigniter

